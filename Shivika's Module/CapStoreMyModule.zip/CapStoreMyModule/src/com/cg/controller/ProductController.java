package com.cg.controller;

import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.service.ProductService;


@Controller
@RequestMapping("/")
public class ProductController {

@Autowired
	ProductService prod_service;

@RequestMapping("/")
	public String home(){
		return "sample";
	}
	
@RequestMapping("/product")	
	public String showProduct(ModelMap map,HttpServletRequest request){
		prod_service.getProductMedia(map,request.getParameter("productId"));
		return "productHome";
	}
}
