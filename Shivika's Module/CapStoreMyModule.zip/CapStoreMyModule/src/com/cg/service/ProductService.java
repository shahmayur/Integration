package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.cg.domain.Media;
import com.cg.domain.Product;
import com.cg.repository.IMedia;
import com.cg.repository.IProduct;
import com.cg.util.ImagePathAndId;


@Service
public class ProductService {

@Value("#{albumResource['imagePath']}")	
String imagePathIP;	
	
@Autowired
IProduct iprod;

@Autowired
IMedia imed;

@Transactional
	public void getProductMedia(ModelMap map, String productId) {
		// TODO Auto-generated method stub
		Product selectedProduct=iprod.findByProductId(productId);
		List<Media> mediaList=imed.findMediaPathByProduct(selectedProduct);
		List<ImagePathAndId> imageList=new ArrayList<ImagePathAndId>();
		System.out.println(imagePathIP);
		int id=0;
		for(Media m:mediaList){
			ImagePathAndId temp=new ImagePathAndId();
			String mediaIP=new String();
			mediaIP=imagePathIP;
			String mediaPath=mediaList.get(mediaList.indexOf(m)).getMediaPath();
			mediaIP=mediaIP.concat(mediaPath);
			temp.setImgPath(mediaIP);
			temp.setId(id);
			imageList.add(temp);
			System.out.println(mediaIP);
			id++;
		}

		System.out.println(imageList.size());
		map.put("productImages",imageList);
	}
}
