package com.cg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.domain.Media;
import com.cg.domain.Product;

public interface IMedia extends JpaRepository<Media,String> {

@Transactional	
	List<Media> findMediaPathByProduct(Product selectedProduct);

}
