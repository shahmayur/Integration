package com.cg.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the returnstatus database table.
 * 
 */
@Entity
public class Returnstatus implements Serializable {
	private static final long serialVersionUID = 1L;
	private String returnstatusId;
	private String returnStatus;
	private Order order;
	private Product product;
	private User user;

	public Returnstatus() {
	}


	@Id
	@Column(name="returnstatus_id")
	public String getReturnstatusId() {
		return this.returnstatusId;
	}

	public void setReturnstatusId(String returnstatusId) {
		this.returnstatusId = returnstatusId;
	}


	@Column(name="return_status")
	public String getReturnStatus() {
		return this.returnStatus;
	}

	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}


	//bi-directional many-to-one association to Order
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="order_id")
	public Order getOrder() {
		return this.order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}


	//bi-directional many-to-one association to Product
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="product_id")
	public Product getProduct() {
		return this.product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}


	//bi-directional many-to-one association to User
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}