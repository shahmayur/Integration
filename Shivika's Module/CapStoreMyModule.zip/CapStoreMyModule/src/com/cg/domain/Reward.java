package com.cg.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigInteger;


/**
 * The persistent class for the rewards database table.
 * 
 */
@Entity
@Table(name="rewards")
public class Reward implements Serializable {
	private static final long serialVersionUID = 1L;
	private String entryId;
	private BigInteger rewardPoints;
	private User user;

	public Reward() {
	}


	@Id
	@Column(name="entry_id")
	public String getEntryId() {
		return this.entryId;
	}

	public void setEntryId(String entryId) {
		this.entryId = entryId;
	}


	@Column(name="reward_points")
	public BigInteger getRewardPoints() {
		return this.rewardPoints;
	}

	public void setRewardPoints(BigInteger rewardPoints) {
		this.rewardPoints = rewardPoints;
	}


	//bi-directional many-to-one association to User
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}