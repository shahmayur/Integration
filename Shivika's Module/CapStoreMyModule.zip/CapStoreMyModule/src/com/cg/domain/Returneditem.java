package com.cg.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigInteger;


/**
 * The persistent class for the returneditems database table.
 * 
 */
@Entity
@Table(name="returneditems")
public class Returneditem implements Serializable {
	private static final long serialVersionUID = 1L;
	private String returnId;
	private BigInteger orderId;
	private double productCost;
	private String productId;
	private String productName;
	private BigInteger productQuantity;
	private String returnStatus;
	private BigInteger returnstatusId;
	private BigInteger transactionId;
	private String userId;

	public Returneditem() {
	}


	@Id
	@Column(name="return_id")
	public String getReturnId() {
		return this.returnId;
	}

	public void setReturnId(String returnId) {
		this.returnId = returnId;
	}


	@Column(name="order_id")
	public BigInteger getOrderId() {
		return this.orderId;
	}

	public void setOrderId(BigInteger orderId) {
		this.orderId = orderId;
	}


	@Column(name="product_cost")
	public double getProductCost() {
		return this.productCost;
	}

	public void setProductCost(double productCost) {
		this.productCost = productCost;
	}


	@Column(name="product_id")
	public String getProductId() {
		return this.productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}


	@Column(name="product_name")
	public String getProductName() {
		return this.productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}


	@Column(name="product_quantity")
	public BigInteger getProductQuantity() {
		return this.productQuantity;
	}

	public void setProductQuantity(BigInteger productQuantity) {
		this.productQuantity = productQuantity;
	}


	@Column(name="return_status")
	public String getReturnStatus() {
		return this.returnStatus;
	}

	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}


	@Column(name="returnstatus_id")
	public BigInteger getReturnstatusId() {
		return this.returnstatusId;
	}

	public void setReturnstatusId(BigInteger returnstatusId) {
		this.returnstatusId = returnstatusId;
	}


	@Column(name="transaction_id")
	public BigInteger getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(BigInteger transactionId) {
		this.transactionId = transactionId;
	}


	@Column(name="user_id")
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}