package com.cg.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the offer database table.
 * 
 */
@Entity
public class Offer implements Serializable {
	private static final long serialVersionUID = 1L;
	private String schemeId;
	private String schemeDescription;
	private String schemeName;
	private String type;
	private String value;
	private Merchant merchant;
	private List<Scheme> schemes;

	public Offer() {
	}


	@Id
	@Column(name="scheme_id")
	public String getSchemeId() {
		return this.schemeId;
	}

	public void setSchemeId(String schemeId) {
		this.schemeId = schemeId;
	}


	@Column(name="scheme_description")
	public String getSchemeDescription() {
		return this.schemeDescription;
	}

	public void setSchemeDescription(String schemeDescription) {
		this.schemeDescription = schemeDescription;
	}


	@Column(name="scheme_name")
	public String getSchemeName() {
		return this.schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}


	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}


	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}


	//bi-directional many-to-one association to Merchant
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="merchant_id")
	public Merchant getMerchant() {
		return this.merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}


	//bi-directional many-to-one association to Scheme
	@OneToMany(mappedBy="offer")
	public List<Scheme> getSchemes() {
		return this.schemes;
	}

	public void setSchemes(List<Scheme> schemes) {
		this.schemes = schemes;
	}

	public Scheme addScheme(Scheme scheme) {
		getSchemes().add(scheme);
		scheme.setOffer(this);

		return scheme;
	}

	public Scheme removeScheme(Scheme scheme) {
		getSchemes().remove(scheme);
		scheme.setOffer(null);

		return scheme;
	}

}