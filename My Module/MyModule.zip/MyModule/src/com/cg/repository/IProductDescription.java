package com.cg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.domain.Product;
import com.cg.domain.Productdescription;

@Repository
public  interface IProductDescription extends JpaRepository<Productdescription,String> {

@Transactional	
	List<Productdescription> findAttributeNameAndAtrributeValueByProduct(Product selectedProduct);


}
