package com.cg.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;


import com.cg.domain.Category;
import com.cg.domain.Media;
import com.cg.domain.Product;
import com.cg.service.ProductService;
import com.cg.util.ImageProdId;

@Controller
public class ProductController {

@Autowired	
private ProductService prod_service;
	
@Value("#{albumResource['path']}")
private String albumpath;

@Value("#{albumResource['drive']}")
private String drive;

@Value("#{albumResource['ipaddress']}")
private String ipaddress;

@RequestMapping("/")	
@Transactional
	public String productHome(HttpServletRequest request,ModelMap map){
		//List<Product> products=prod_service.getProducts();
		List<Media> media=prod_service.getMedia();
		List<ImageProdId> mediaList=new ArrayList<ImageProdId>();
		System.out.println(media.size());
		for(Media m:media){
			ImageProdId temp=new ImageProdId();
			temp.setImgPath(ipaddress+m.getMediaPath());
			temp.setProdId(m.getProduct().getProductId());
			mediaList.add(temp);
		}
		map.put("imageList",mediaList);
		return "productHome";
	}
@RequestMapping("/product")
@Transactional
	public String selectedProduct(HttpServletRequest request,ModelMap map){
		String productId=request.getParameter("prodId");
		map.put("selectedProduct",productId);
		prod_service.findSimilarProducts(productId,map);
		return "product";
	}
@RequestMapping("/compare")
	public String compareProducts(HttpServletRequest request,ModelMap map){
		String productId=request.getParameter("prodId");
		String[] comparisonProducts=request.getParameterValues("similarProducts");
		prod_service.getProductDescription(comparisonProducts,productId,map);
		return "compare";
	}

}
