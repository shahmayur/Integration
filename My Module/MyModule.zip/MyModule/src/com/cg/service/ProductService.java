package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.cg.domain.Category;
import com.cg.domain.Media;
import com.cg.domain.Product;
import com.cg.domain.Productdescription;
import com.cg.repository.ICategory;
import com.cg.repository.IMedia;
import com.cg.repository.IProduct;
import com.cg.repository.IProductDescription;
import com.cg.util.ImageProdId;
import com.cg.util.ProductDescAndImage;

@Service
public class ProductService {
	@Autowired
	private ICategory icat;

	@Autowired
	private IMedia imed;

	@Autowired
	private IProduct iprod;

	@Autowired
	private IProductDescription iprodDesc;
	
	@Value("#{albumResource['ipaddress']}")
	private String ipaddress;
	
	public List<String> getAlbumPath(){
		return imed.getMediaPath();
	}

	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		
		return iprod.findAll();
	}

	public String getTags(String prodId) {
		// TODO Auto-generated method stub
		return null;
	//	return iprod.findProductTagByProductId(prodId);
	}

	public List<Product> getProductsByCategory(Category category) {
		// TODO Auto-generated method stub
		return iprod.findByCategory(category);
	}

	public Category getCategory(String prodId) {
		// TODO Auto-generated method stub
		return iprod.findCategoryId(prodId);
	}

	public List<Media> getMedia() {
		// TODO Auto-generated method stub
		return imed.findAll();
	}

	@Transactional
	public void findSimilarProducts(String productId, ModelMap map) {
		// TODO Auto-generated method stub
		Product product=iprod.findByProductId(productId);
		String[] selected_prod_tags=product.getProductTag().split(",");
		List<Product> prod_list=iprod.findByCategory(product.getCategory());
		List<ImageProdId> mediaList=new ArrayList<ImageProdId>();
		System.out.println("Similar Products"+prod_list.size());
		for(Product p:prod_list){
			if(p.getProductId().equalsIgnoreCase(product.getProductId())){
				continue;
			}
			String similar_tags=p.getProductTag();
			for(String tag:selected_prod_tags){
				if(similar_tags.contains(tag)){
					String imagePath=new String();
					imagePath=ipaddress;
					ImageProdId temp=new ImageProdId();
					System.out.println("Found tag:"+tag);
					List<Media> similar_product=imed.findByMediaTypeAndProduct("IMAGE",p);
					//System.out.println(similar_product.getProduct().getProductId());
					Media similar_product_media=similar_product.get(0);
					imagePath=imagePath.concat(similar_product_media.getMediaPath());
					temp.setImgPath(imagePath);
					temp.setProdId(similar_product_media.getProduct().getProductId());
					mediaList.add(temp);
					break;
				}
			}	
		}
		map.put("imageListSize",mediaList.size());
		map.put("productList",mediaList);
		//return map;
	}
	
	@Transactional
	public void getProductDescription(String[] comparisonProducts, String productId, ModelMap map) {
		// TODO Auto-generated method stub
		List<ProductDescAndImage> productDescImage=new ArrayList<ProductDescAndImage>();
		List<Media> selectedProductMedia=imed.findMediaTypeByProduct(iprod.findByProductId(productId));
		Product selectedProduct=iprod.findByProductId(productId);
		List<Productdescription> selected_prod_desc=iprodDesc.findAttributeNameAndAtrributeValueByProduct(selectedProduct);
		ProductDescAndImage curr_prod=new ProductDescAndImage();
		curr_prod.setImage(selectedProductMedia.get(0).getMediaPath());
		curr_prod.setProddescription(selected_prod_desc);
		productDescImage.add(curr_prod);

		for(String prodId:comparisonProducts){
			ProductDescAndImage temp=new ProductDescAndImage();
			Product comparisonProduct=new Product();
			comparisonProduct=iprod.findByProductId(prodId);
			List<Productdescription> prod_desc=iprodDesc.findAttributeNameAndAtrributeValueByProduct(comparisonProduct);
			List<Media> mediaPath=imed.findByMediaTypeAndProduct("IMAGE",iprod.findByProductId(prodId));
			String imagePath=ipaddress+mediaPath.get(0).getMediaPath();
			temp.setProddescription(prod_desc);
			temp.setImage(imagePath);
			productDescImage.add(temp);
		}
		System.out.println(productDescImage.size());
		map.put("productDescription",productDescImage);
	}
}
