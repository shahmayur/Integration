package com.cg.util;

import java.util.List;

import com.cg.domain.Productdescription;

public class ProductDescAndImage {
	List<Productdescription> proddescription;
	String image;
	public List<Productdescription> getProddescription() {
		return proddescription;
	}
	public void setProddescription(List<Productdescription> proddescription) {
		this.proddescription = proddescription;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
}
