package com.cg.domian;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the user database table.
 * 
 */
@Entity
public class User implements Serializable {
	private static final long serialVersionUID = 1L;
	private String userId;
	private Date userAddeddate;
	private String userAddress;
	private String userEmail;
	private String userFirstname;
	private String userLastname;
	private String userPassword;
	private Date userRemoveddate;
	private String userSecurityanswer;
	private String userSecurityquestion;
	private String userStatus;
	private List<Feedback> feedbacks;
	private List<Order> orders;
	private List<Returnstatus> returnstatuses;
	private List<Reward> rewards;
	private List<Shipping> shippings;
	private List<Wishlist> wishlists;

	public User() {
	}


	@Id
	@Column(name="user_id")
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}


	@Temporal(TemporalType.DATE)
	@Column(name="user_addeddate")
	public Date getUserAddeddate() {
		return this.userAddeddate;
	}

	public void setUserAddeddate(Date userAddeddate) {
		this.userAddeddate = userAddeddate;
	}


	@Column(name="user_address")
	public String getUserAddress() {
		return this.userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}


	@Column(name="user_email")
	public String getUserEmail() {
		return this.userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	@Column(name="user_firstname")
	public String getUserFirstname() {
		return this.userFirstname;
	}

	public void setUserFirstname(String userFirstname) {
		this.userFirstname = userFirstname;
	}


	@Column(name="user_lastname")
	public String getUserLastname() {
		return this.userLastname;
	}

	public void setUserLastname(String userLastname) {
		this.userLastname = userLastname;
	}


	@Column(name="user_password")
	public String getUserPassword() {
		return this.userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	@Temporal(TemporalType.DATE)
	@Column(name="user_removeddate")
	public Date getUserRemoveddate() {
		return this.userRemoveddate;
	}

	public void setUserRemoveddate(Date userRemoveddate) {
		this.userRemoveddate = userRemoveddate;
	}


	@Column(name="user_securityanswer")
	public String getUserSecurityanswer() {
		return this.userSecurityanswer;
	}

	public void setUserSecurityanswer(String userSecurityanswer) {
		this.userSecurityanswer = userSecurityanswer;
	}


	@Column(name="user_securityquestion")
	public String getUserSecurityquestion() {
		return this.userSecurityquestion;
	}

	public void setUserSecurityquestion(String userSecurityquestion) {
		this.userSecurityquestion = userSecurityquestion;
	}


	@Column(name="user_status")
	public String getUserStatus() {
		return this.userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}


	//bi-directional many-to-one association to Feedback
	@OneToMany(mappedBy="user")
	public List<Feedback> getFeedbacks() {
		return this.feedbacks;
	}

	public void setFeedbacks(List<Feedback> feedbacks) {
		this.feedbacks = feedbacks;
	}

	public Feedback addFeedback(Feedback feedback) {
		getFeedbacks().add(feedback);
		feedback.setUser(this);

		return feedback;
	}

	public Feedback removeFeedback(Feedback feedback) {
		getFeedbacks().remove(feedback);
		feedback.setUser(null);

		return feedback;
	}


	//bi-directional many-to-one association to Order
	@OneToMany(mappedBy="user")
	public List<Order> getOrders() {
		return this.orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public Order addOrder(Order order) {
		getOrders().add(order);
		order.setUser(this);

		return order;
	}

	public Order removeOrder(Order order) {
		getOrders().remove(order);
		order.setUser(null);

		return order;
	}


	//bi-directional many-to-one association to Returnstatus
	@OneToMany(mappedBy="user")
	public List<Returnstatus> getReturnstatuses() {
		return this.returnstatuses;
	}

	public void setReturnstatuses(List<Returnstatus> returnstatuses) {
		this.returnstatuses = returnstatuses;
	}

	public Returnstatus addReturnstatus(Returnstatus returnstatus) {
		getReturnstatuses().add(returnstatus);
		returnstatus.setUser(this);

		return returnstatus;
	}

	public Returnstatus removeReturnstatus(Returnstatus returnstatus) {
		getReturnstatuses().remove(returnstatus);
		returnstatus.setUser(null);

		return returnstatus;
	}


	//bi-directional many-to-one association to Reward
	@OneToMany(mappedBy="user")
	public List<Reward> getRewards() {
		return this.rewards;
	}

	public void setRewards(List<Reward> rewards) {
		this.rewards = rewards;
	}

	public Reward addReward(Reward reward) {
		getRewards().add(reward);
		reward.setUser(this);

		return reward;
	}

	public Reward removeReward(Reward reward) {
		getRewards().remove(reward);
		reward.setUser(null);

		return reward;
	}


	//bi-directional many-to-one association to Shipping
	@OneToMany(mappedBy="user")
	public List<Shipping> getShippings() {
		return this.shippings;
	}

	public void setShippings(List<Shipping> shippings) {
		this.shippings = shippings;
	}

	public Shipping addShipping(Shipping shipping) {
		getShippings().add(shipping);
		shipping.setUser(this);

		return shipping;
	}

	public Shipping removeShipping(Shipping shipping) {
		getShippings().remove(shipping);
		shipping.setUser(null);

		return shipping;
	}


	//bi-directional many-to-one association to Wishlist
	@OneToMany(mappedBy="user")
	public List<Wishlist> getWishlists() {
		return this.wishlists;
	}

	public void setWishlists(List<Wishlist> wishlists) {
		this.wishlists = wishlists;
	}

	public Wishlist addWishlist(Wishlist wishlist) {
		getWishlists().add(wishlist);
		wishlist.setUser(this);

		return wishlist;
	}

	public Wishlist removeWishlist(Wishlist wishlist) {
		getWishlists().remove(wishlist);
		wishlist.setUser(null);

		return wishlist;
	}

}