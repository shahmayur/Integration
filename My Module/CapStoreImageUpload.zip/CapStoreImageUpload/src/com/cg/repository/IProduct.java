package com.cg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.domian.Product;

public interface IProduct extends JpaRepository<Product,String> {

@Transactional	
	Product findByProductId(String productId);

}
