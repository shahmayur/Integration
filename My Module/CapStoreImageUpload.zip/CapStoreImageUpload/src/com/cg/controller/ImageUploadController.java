package com.cg.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.cg.domian.Media;
import com.cg.domian.Product;
import com.cg.repository.IMedia;
import com.cg.repository.IProduct;


@Controller
@RequestMapping("/")	
public class ImageUploadController {

@Autowired
	IMedia imed;

@Autowired
	IProduct iprod;
	
@Value("#{albumResource['drive']}")	
	private String drive;
@RequestMapping("/")	
	public String sampleHome(){
		return "home";
	}
	
@RequestMapping("/upload")	
	public void imageUploadHome(@RequestParam("album")MultipartFile album,HttpServletRequest request,HttpServletResponse response){
	ZipFile albums_zip=null;
	boolean create_dir=false;
	Product curr_prod=null;
	String contextPath=request.getContextPath();
	System.out.println(contextPath);
		try {
			System.out.println(drive);
			File file=new File(drive+album.getOriginalFilename());
			FileUtils.writeByteArrayToFile(file,album.getBytes());
			albums_zip=new ZipFile(file);
			Enumeration<?> zipContents=albums_zip.entries();
			String directory_name=album.getOriginalFilename();
			String [] splitter=directory_name.split("\\.");
			directory_name=splitter[0];
			File dir=new File(drive+directory_name);
			dir.mkdirs();
			while(zipContents.hasMoreElements()){
				ZipEntry entry=(ZipEntry) zipContents.nextElement();
				//System.out.println(entry.getName());
				File destinationPath = new File(drive+directory_name, entry.getName());
				String path_to_be_saved=directory_name+"/"+entry.getName();
				 create_dir=destinationPath.getParentFile().mkdirs();
				 System.out.println(create_dir);
				 if (entry.isDirectory()) {
					 System.out.println("File name is directory!");
					 String productId=new String();
					 splitter=entry.getName().split("\\/");
					 productId=splitter[0];
					 System.out.println("Product Id:"+productId);
					 curr_prod=iprod.findByProductId(productId);
					 continue;
				 }
				 else{
					 	Media prod_media=new Media();
					 	String finalPath=contextPath+"/"+path_to_be_saved;
					    System.out.println("Extracting file: " + destinationPath);					                   
					    BufferedInputStream bis = new BufferedInputStream(albums_zip.getInputStream(entry));
					    int b;
					    byte buffer[] = new byte[1024];
					    FileOutputStream fos = new FileOutputStream(destinationPath);
					    BufferedOutputStream bos = new BufferedOutputStream(fos, 1024);
					    while ((b = bis.read(buffer, 0, 1024)) != -1) {
					              bos.write(buffer, 0, b);
					     }
					    prod_media.setProduct(curr_prod);
					    prod_media.setMediaType("IMAGE");
					    prod_media.setMediaPath(finalPath);
					    imed.saveAndFlush(prod_media);
					    bos.close();
					    bis.close();		                      
				 }

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
            try {
                if (albums_zip!=null) {
                    albums_zip.close();
                }
            }
            catch (IOException ioe) {
                   System.out.println("Error while closing zip file" + ioe);
            }
        }
//CapStoreApplicationContextPath		
		try {
			response.sendRedirect("http://10.102.54.139:1729/Integration/mediauploaded");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
